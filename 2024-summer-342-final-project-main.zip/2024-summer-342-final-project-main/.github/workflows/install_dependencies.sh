#!/bin/bash

sudo apt-get update 
sudo apt-get install -y g++ cmake make valgrind lcov python3
