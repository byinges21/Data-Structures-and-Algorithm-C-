#!/bin/bash

cfg=`find ~ -name "backref.cfg"`
