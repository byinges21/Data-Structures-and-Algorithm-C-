#include <cstdio>

/*
 * This file is run through memory check.
 * However, any changes in this file will be ignored for grading, EXCEPT its memory leak
 * Meaning, if there's memory leak from this file, there will be points penalty
 */

int main() {
    /*
     * Left empty on purpose.
     */
}